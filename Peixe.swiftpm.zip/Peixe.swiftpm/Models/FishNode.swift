import Foundation
import SceneKit

class FishNode: SCNNode {
    override init() {
        super.init()
        configureGeometry()
        fishMovement()
        
        position.x = Float.random(in: 5.5 ... 8.3)
        position.y = Float.random(in: -6.5 ... -4.5)
        position.z = Float.random(in: -24.5 ... -21.5)
        scale = SCNVector3(x: 0.2, y: 0.2, z: 0.2)
        
        
    }
    
    func fishMovement() {
            let rotationA = SCNAction.rotateBy(x: 0, y: -.pi , z: 0, duration: 0.5)
            let rotationB = SCNAction.rotateBy(x: 0, y: -.pi , z: 0, duration: 0.5)
            
            let destinationA = SCNAction.moveBy(x: -2, y: -1, z: -3, duration: 10)
            let destinationc = SCNAction.moveBy(x: 2, y: 1, z: 3, duration: 10)
            
            let sequence = SCNAction.sequence([destinationA, rotationA, destinationc, rotationB])
            self.runAction(SCNAction.repeatForever(sequence))
        
                
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configureGeometry() {
        guard let grassScene = SCNScene(named: "fish.scn") else {
            fatalError("Erro ao carregar a cena de grama do arquivo .scn")
        }
        

        for childNode in grassScene.rootNode.childNodes {
            self.addChildNode(childNode)
        }
    }
    

}
