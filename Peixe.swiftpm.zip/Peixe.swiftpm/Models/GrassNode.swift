import SceneKit

class GrassNode: SCNNode {
    
    override init() {
        super.init()
        configureGeometry()
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configureGeometry() {
        let grassScene = SCNScene(named: "grass.scn")!
        let bigGrassScene = SCNScene(named: "bigGrass.scn")!
        
        let random = Int.random(in: 1...30)
        
        if random == 1 {
            for childNode in bigGrassScene.rootNode.childNodes {
                self.addChildNode(childNode)
                position.x = Float.random(in: 0 + 6 ... 2.3 + 6)
                position.y = 1 - 10
                position.z = Float.random(in: -3.3 - 25 ... -2.6 - 25)
                scale.y = Float.random(in: 0.3...0.8)
                scale.x = Float.random(in: 0.3...0.5)
                scale.z = Float.random(in: 0.3...0.5)
                eulerAngles.y = Float.random(in: -.pi/4 ... .pi/4)
                name = "bigGrass"
                
            }
        } else {
            for childNode in grassScene.rootNode.childNodes {
                self.addChildNode(childNode)
                
                position.x = Float.random(in: -2.2 + 6 ... 2.2 + 6)
                position.y = 1 - 10
                position.z = Float.random(in: -3.7 - 25 ... 3.7 - 25)
                scale.y = Float.random(in: 0.2...0.3)
                scale.x = Float.random(in: 0.2...0.3)
                scale.z = Float.random(in: 0.2...0.3)
                eulerAngles.y = Float.random(in: -.pi ... .pi)
                name = "grass"
                
            }
        }
    }
}
