import SwiftUI

struct PhaseModel {
    var name: String
    var description: String
    var steps: [StepModel]
}



