import SceneKit

class PlantNode: SCNNode {
    override init() {
        super.init()
        configureGeometry()
        
        position.x = Float.random(in: -2 ... 2)
        position.y = 1
        position.z = Float.random(in: -3.5 ... 0)
        scale = SCNVector3(x: Float.random(in: 0.03...0.06), y: Float.random(in: 0.1...0.25), z: Float.random(in: 0.03...0.06))
        

    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configureGeometry() {
        guard let grassScene = SCNScene(named: "plant.scn") else {
            fatalError("Erro ao carregar a cena de grama do arquivo .scn")
        }
        

        for childNode in grassScene.rootNode.childNodes {
            self.addChildNode(childNode)
        }
    }
}
