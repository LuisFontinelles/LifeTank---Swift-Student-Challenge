import Foundation
import SwiftUI

struct StepModel: Equatable {
    var name: String
    var sliderValue: Double
    var maxSliderRange: Double //max range of the slider
    var isSliderStep: Bool? //slider uses specific step or not?
    var isEnabled: Bool
    var description: String
    var maxIdealrange: Double
    var minIdealrange: Double
}
