import SwiftUI
import SceneKit

struct ContentView: View {
    @StateObject private var fishViewController: FishViewController

    @State var sliderLuminous: Double = 0
    @State var sliderGrass: Double = 0
    @State var sliderFish: Double = 0
    @State var sliderPH: Double = 0
    @State var sliderWaterPuriry: Double = 0
    @State var sliderWater: Double = 0
    @State var sliderSoil: Double = 0
    @State var sliderNutrition: Double = 0
    @State var sliderTree: Double = 0
    @State var sliderRock: Double = 0
    
    @State var phValue: CGFloat = 5

    @State private var showPhasesView = false
    @State private var isHomeViewPresented = false

    let sharedScene : SCNScene
    init() {
        // Capturando 'self' como uma cópia local
        let scene = SCNScene(named: "MainScene.scn") ?? SCNScene()
        sharedScene = scene
        _fishViewController = StateObject(wrappedValue: FishViewController(scene: scene))
    }
    var body: some View {
        HStack {
            if showPhasesView {
                ARSceneViewRepresentable(scene: sharedScene)
                    .edgesIgnoringSafeArea(.all)
                    .navigationBarBackButtonHidden(true)
                    .navigationBarItems(leading: Button(action: {
                        isHomeViewPresented.toggle()
                    }) {
                        Image(systemName: "arrow.left.circle.fill")
                            .foregroundColor(.white)
                            .font(.title)
                    })
            } else {
                HStack {
                    ZStack {
                        FishRepresentable(
                            fishViewController: fishViewController,
                            scene: sharedScene,
                            sliderFishValue: $sliderLuminous,
                            sliderGrass: $sliderGrass,
                            sliderFish: $sliderFish,
                            sliderPH: $sliderPH,
                            sliderWaterPurity: $sliderWaterPuriry,
                            sliderWater: $sliderWater,
                            sliderSoil: $sliderSoil,
                            sliderNutrition: $sliderNutrition,
                            sliderTree: $sliderTree,
                            sliderRock: $sliderRock
                        )
                        .frame(width: UIScreen.main.bounds.width * 3 / 5)
                    .edgesIgnoringSafeArea(.all)
                        HUDView(phValue: $phValue, sliderGrass: $sliderGrass,
                                sliderFish: $sliderFish,
                                sliderLight: $sliderLuminous)
                    }

                    PhasesView(
                        sliderLight: $sliderLuminous,
                        sliderGrass: $sliderGrass,
                        sliderFish: $sliderFish,
                        sliderPH: $sliderPH,
                        sliderWaterPurity: $sliderWaterPuriry,
                        sliderWater: $sliderWater,
                        sliderSoil: $sliderSoil,
                        sliderNutrition: $sliderNutrition,
                        sliderTree: $sliderTree,
                        sliderRock: $sliderRock, 
                        phValue: phValue,
                        fishVC: fishViewController,
                        showPhasesView: $showPhasesView
                    )
                    .frame(width: UIScreen.main.bounds.width * 2 / 5)
                    .frame(maxHeight: .infinity)
                    .edgesIgnoringSafeArea(.all)

                }
            }
        }
        .fullScreenCover(isPresented: $isHomeViewPresented, content: {
            HomeView()
        })

    }
}


#Preview {
    ContentView()
}
