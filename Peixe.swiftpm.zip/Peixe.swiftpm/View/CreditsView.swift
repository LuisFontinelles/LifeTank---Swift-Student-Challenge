import SwiftUI

struct CreditsView: View {
    var body: some View {
        VStack {
            Text("Credits")
                .bold()
                .foregroundStyle(.black)
                .padding()
                .font(.system(size:UIScreen.main.bounds.width/8))
            Text("Life Tank was created by Luis Filipe Fontinelles em Brasília - DF, Brazil.")
                .font(.largeTitle)
                .foregroundStyle(.black)
                .bold()
                .frame(maxWidth: UIScreen.main.bounds.width * 0.8)

            Text("This scene is a reflection of my personal journey, where each meticulously placed element in the aquarium represents not just a piece of decoration, but an active participant in this delicate balance of aquatic life.")
                .font(.title2)
                .foregroundStyle(.black)
                .frame(maxWidth: UIScreen.main.bounds.width * 0.8)
                .multilineTextAlignment(.center)
            Spacer()
            HStack {
                VStack {
                    VStack{
                        Text("Sounds")
                            .font(.title)
                            .foregroundStyle(.black)
                            .bold()
                            .multilineTextAlignment(.center)

                        Text("All game sound assets were recorded and edited by Luis Fontinelles.")
                            .font(.callout)
                            .foregroundStyle(.black)
                            .multilineTextAlignment(.center)

                    }
                    .padding()
                    Text("Assets")
                        .font(.title)
                        .bold()
                        .foregroundStyle(.black)
                        .multilineTextAlignment(.center)


                    Text("All 3D assets in the game were created by Luis Fontinelles, showcasing a dedication to craftsmanship and creativity, The stunning water images used in the game were sourced from pixel-furnace.com, under a free license agreement.")
                        .font(.callout)
                        .foregroundStyle(.black)
                        .multilineTextAlignment(.center)


                }
                .frame(maxHeight: .infinity)
                Spacer()
                VStack {
                    
                    Text("Greetings")
                        .font(.title)
                        .multilineTextAlignment(.center)

                        .bold()
                        .foregroundStyle(.black)

                    Text("I want to thank my design and code mentors, whose guidance was crucial. I also appreciate my colleagues for their valuable support and my parents for their constant encouragement. The achievement of this project is the result of collective work and the incredible support from everyone. Thank you!")
                        .multilineTextAlignment(.center)

                        .font(.callout)
                        .foregroundStyle(.black)

                }
                .padding()
                .frame(maxHeight: .infinity)

                

                
            }
            Spacer()
        }
        .background(Color.white)


        .padding()
        .ignoresSafeArea()
    }
}

#Preview {
    CreditsView()
}
