import SwiftUI

struct HUDView: View {
    @State private var o2Value: Int = 0
    @State private var nh3Value: Int = 0
    @Binding var phValue: CGFloat
    @Binding var sliderGrass: Double
    @Binding var sliderFish: Double
    @Binding var sliderLight: Double
    @State var isShowing = false
    @State private var isImageVisible = true // State para controlar a visibilidade da imagem
    
    
    var body: some View {
        VStack{
            
            if sliderLight > 800 {
                VStack {
                    ZStack {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .resizable()
                            .frame(width: 80, height: 80)
                            .foregroundStyle(.black)
                            .opacity(isImageVisible ? 1.0 : 0.0)
                            .blur(radius: 5)
                        Image(systemName: "exclamationmark.triangle.fill")
                            .resizable()
                            .frame(width: 70, height: 70)
                            .foregroundStyle(.yellow)
                            .opacity(isImageVisible ? 1.0 : 0.0)
                    }
                    Text("Algae Infestation")
                        .foregroundStyle(.black)
                        .font(.largeTitle)
                        .opacity(isImageVisible ? 1.0 : 0.0) // Aplicar animação à opacidade também
                }
                .onAppear {
                    startBlinking()
                }
                
            } else if sliderFish > 25 {
                VStack {
                    ZStack {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .resizable()
                            .frame(width: 80, height: 80)
                            .foregroundStyle(.black)
                            .blur(radius: 5)
                            .opacity(isImageVisible ? 1.0 : 0.0)
                        Image(systemName: "exclamationmark.triangle.fill")
                            .resizable()
                            .frame(width: 70, height: 70)
                            .foregroundStyle(.yellow)
                            .opacity(isImageVisible ? 1.0 : 0.0)
                    }
                    Text("Excess Ammonia")
                        .foregroundStyle(.black)
                        .font(.largeTitle)
                        .opacity(isImageVisible ? 1.0 : 0.0) // Aplicar animação à opacidade também
                }
                .onAppear {
                    startBlinking()
                }
            }
            
        }
    }
    
    func startBlinking() {
        withAnimation(Animation.easeInOut(duration: 0.5).repeatForever()) {
            isImageVisible.toggle()
        }
    }
}
