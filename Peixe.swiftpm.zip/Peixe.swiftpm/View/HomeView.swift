import SwiftUI

struct HomeView: View {
    @State private var isPresented = false
    
    var body: some View {
        
        NavigationStack {
            VStack{
                Text("Life Tank")
                    .font(.system(size:UIScreen.main.bounds.width/8))
                    .bold()
                    .padding()
                    .foregroundStyle(Color.white)
                
                Spacer()
                
                VStack {
                    Button {
                        withAnimation(.spring) {
                            isPresented.toggle()
                        }
                    } label: {
                        Text("Start")
                            .padding()
                            .font(.largeTitle)
                            .bold()
                            .background(Color.cyan)
                            .containerShape(RoundedRectangle(cornerRadius: 10))
                            .foregroundStyle(Color.white)

                        
                    }
                    .fullScreenCover(isPresented: $isPresented, content: {
                        ContentView()
                    })
                }
                NavigationLink {
                    CreditsView()
                } label: {
                    Text("Credits")
                        .padding()
                        .font(.title)
                        .bold()
                        .foregroundColor(.white)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.cyan, lineWidth: 4)
                        )

                }
                Spacer()
                HStack {
                    Text("A WWDC Swift Student Challenge submission by Luis Fontinelles")
                        .font(.caption)
                        .foregroundStyle(.white)
                    Spacer()
                }
                
            }
            .padding()
            .background {
                Image("waterBG")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
            }
        }
    }
}

#Preview {
    HomeView()
}
