import SwiftUI

struct ModalView: View {
    @ObservedObject var fishVC: FishViewController
    @Binding var isPresented: Bool
    @Binding var showPhasesView: Bool
    var currentIndex: Int
    var gameVM: GameViewModel
    
    var body: some View {
        ZStack {
            Color("\(gameVM.phases[gameVM.currentPhaseIndex].name)1")

            if currentIndex == 0 {
                TabView {
                    VStack {
                        HStack {
                            Text("General Introduction")
                                .font(.largeTitle)
                                .padding(.bottom,50)
                                .foregroundStyle(Color(gameVM.phases[gameVM.currentPhaseIndex].name))
                                .bold()
                                .multilineTextAlignment(.center)

//                            Spacer()
                        }
                        
                        Text("Welcome to a simulated aquarium journey, where we'll explore and seek to understand the fascinating workings of an aquatic system. Throughout the three stages - Foundation, Aquatic Medium, and Biodiversity - we'll dive into creating a virtual ecosystem, unraveling the secrets of aquatic life.")
                            .font(.largeTitle)
                            .foregroundStyle(Color(gameVM.phases[gameVM.currentPhaseIndex].name))
                            .multilineTextAlignment(.center)

                        Spacer()
                        
                    }
                    .padding(24)

                    .tag(0)
                    
                    VStack {
                        HStack {
                            Text(gameVM.phases[gameVM.currentPhaseIndex].name)
                                .font(.largeTitle)
                                .padding(.bottom,50)
                                .foregroundStyle(Color(gameVM.phases[gameVM.currentPhaseIndex].name))
                                .bold()
                                .multilineTextAlignment(.center)

//                            Spacer()
                        }
                        Text(gameVM.phases[gameVM.currentPhaseIndex].description)
                            .font(.largeTitle)
                            .foregroundStyle(Color(gameVM.phases[gameVM.currentPhaseIndex].name))
                            .multilineTextAlignment(.center)

                        Spacer()
                        
                    }
                    .padding(24)

                    .tag(1)
                }
                .tabViewStyle(PageTabViewStyle())
                .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
            } else {
                VStack {
                    HStack {
                        Text(gameVM.phases[gameVM.currentPhaseIndex].name)
                            .font(.largeTitle)
                            .padding(.bottom,50)
                            .foregroundStyle(Color(gameVM.phases[gameVM.currentPhaseIndex].name))
                            .bold()
                            .multilineTextAlignment(.center)

//                        Spacer()
                    }
                    Text(gameVM.phases[gameVM.currentPhaseIndex].description)
                        .font(.largeTitle)
                        .foregroundStyle(Color(gameVM.phases[gameVM.currentPhaseIndex].name))
                        .multilineTextAlignment(.center)

                    Spacer()
                    
                }
                
                .padding(24)
                
            }
        }
        .onTapGesture {
            isPresented.toggle()
        }
    }
    
}

#Preview {
    ContentView()
}


struct FinalModalView: View {
    var currentIndex: Int
    var gameVM: GameViewModel
    @Binding var isPresentedFinal: Bool
    @Binding var showPhasesView: Bool


    var body: some View {
        VStack {
            VStack{
                Text("Congratulations! Your Aquarium is Ready!")
                    .font(.largeTitle)
                    .padding(.bottom, 32)
                    .foregroundStyle(Color(UIColor(red: 0.1137, green: 0.1529, blue: 0.1882, alpha: 1)))

                Text("You did it! You've built a healthy and balanced aquatic environment, gaining a deeper understanding of an entire aquatic ecosystem. Now, bring your system to life! Find a well-lit and spacious area to visualize it and make the most of your aquatic masterpiece. Enjoy exploring the outcome of your efforts!")
                    .font(.title)
                    .multilineTextAlignment(.center)
                    .foregroundStyle(Color(UIColor(red: 0.1137, green: 0.1529, blue: 0.1882, alpha: 1)))
            }
            .padding(24)
            Spacer()
            if currentIndex == 2 {
                Button {
                    withAnimation {
                        // Atualize a lógica conforme necessário
                        if showPhasesView {
                            // Realize qualquer ação necessária antes de mudar para a ARScene
                            // Exemplo: fishVC.setupAR()
                        }
                        showPhasesView.toggle()
                    }
                    isPresentedFinal.toggle()
                } label: {
                    Text("Start")
                        .padding()
                        .font(.largeTitle)
                        .bold()
                        .background(Color.cyan)
                        .containerShape(RoundedRectangle(cornerRadius: 10))
                        .foregroundStyle(Color.white)
                }
            }
            
        }
        .padding()
        .background(Color(UIColor(red: 0.2980, green: 0.4745, blue: 0.6275, alpha: 1)))

    }
}
