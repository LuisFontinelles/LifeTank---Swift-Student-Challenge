import SwiftUI

struct PhasesView: View {
    
    //sliders values
    @Binding var sliderLight: Double
    @Binding var sliderGrass: Double
    @Binding var sliderFish: Double
    @Binding var sliderPH: Double
    @Binding var sliderWaterPurity: Double
    @Binding var sliderWater: Double
    @Binding var sliderSoil: Double
    @Binding var sliderNutrition: Double
    @Binding var sliderTree: Double
    @Binding var sliderRock: Double
    
    @State var phValue: CGFloat = 5
    
    
    @StateObject var fishVC: FishViewController
    @StateObject private var gameVM = GameViewModel()
    
    @State private var isPresented = true
    @State private var isPresentedFinal = false
    
    @Binding var showPhasesView: Bool

    
    var body: some View {
        ZStack{
            Color((gameVM.phases[gameVM.currentPhaseIndex].name))
                .offset(x: -8)
            VStack {
                ZStack {
                    Color("\(gameVM.phases[gameVM.currentPhaseIndex].name)1")
                        .onTapGesture {
                            isPresented.toggle()
                        }
                    VStack {
                        Spacer()
                        HStack {
                            Text(gameVM.phases[gameVM.currentPhaseIndex].name)
                                .font(.title)
                                .bold()
                                .foregroundStyle(Color(gameVM.phases[gameVM.currentPhaseIndex].name))
                                .padding(.horizontal,24)
                            Spacer()
                        }
                        Spacer()
                        HStack {
                            Spacer()
                            
                            Text("\(gameVM.currentPhaseIndex + 1)/\(gameVM.phases.count)")
                                .font(.callout)
                                .foregroundStyle(Color(gameVM.phases[gameVM.currentPhaseIndex].name))
                        }
                        .padding()
                    }
                }
                .frame(height: UIScreen.main.bounds.height/7)
                .frame(maxWidth: .infinity)
                .padding(.leading, -8)
                //            .padding(.top, -32)
                
                VStack {
                    HStack {
                        ScrollView {
                            ForEach(gameVM.phases[gameVM.currentPhaseIndex].steps.indices, id: \.self) { step in
                                if step < gameVM.phases[gameVM.currentPhaseIndex].steps.count {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 25)
                                            .foregroundStyle(Color("\(gameVM.phases[gameVM.currentPhaseIndex].name)1"))
                                            .frame(maxWidth: .infinity)
                                        VStack{
                                            HStack {
                                                Text(gameVM.phases[gameVM.currentPhaseIndex].steps[step].name)
                                                    .foregroundStyle(Color(gameVM.phases[gameVM.currentPhaseIndex].name))
                                                    .bold()
                                                
                                                Spacer()
                                            }
                                            
                                            Slider(
                                                value: bindingForStep(step, inPhase: gameVM.currentPhaseIndex),
                                                in: 0.0 ... gameVM.phases[gameVM.currentPhaseIndex].steps[step].maxSliderRange,
                                                step: gameVM.phases[gameVM.currentPhaseIndex].steps[step].isSliderStep != nil ? 1 : 0.001
                                            )
                                            .tint(Color(gameVM.phases[gameVM.currentPhaseIndex].name))
                                            
                                            .disabled(isSliderDisabled(for: step))
                                            .onChange(of: bindingForStep(step, inPhase: gameVM.currentPhaseIndex).wrappedValue) { newValue in
                                                handleSliderChange(step, newValue)
                                            }
                                            
                                            // Exibindo a descrição do passo correspondente ao slider ativo
                                            Text(gameVM.phases[gameVM.currentPhaseIndex].steps[step].description)
                                                .font(.callout)
                                                .foregroundStyle(Color(gameVM.phases[gameVM.currentPhaseIndex].name))
                                                .padding(.bottom, 12)
                                        }
                                        .padding()
                                    }
                                }
                            }
                        }
                    }
                    .padding()
                }
                .ignoresSafeArea()
                Spacer()
                HStack {
                    ZStack {
                        RoundedRectangle(cornerRadius: 25)
                            .foregroundStyle(Color("\(gameVM.phases[gameVM.currentPhaseIndex].name)1").opacity(gameVM.isNextButtonEnabled ? 1.0 : 0.6))
                            .frame(maxWidth: .infinity)
                            .padding()


                        Button {
                            if gameVM.currentPhaseIndex == 2 {
                                isPresentedFinal.toggle()
                                // fishVewControllerL.setupAR()
                            } else {
                                gameVM.nextPhase()
                            }
                            //                    isPresented.toggle()
                        } label: {
                            ZStack{
                                RoundedRectangle(cornerRadius: 25)
                                    .foregroundStyle(Color("\(gameVM.phases[gameVM.currentPhaseIndex].name)1"))
                                Text("NEXT")
                                    .font(.callout)
                                    .bold()
                                    .padding()
                                    .foregroundColor(Color((gameVM.phases[gameVM.currentPhaseIndex].name)))
                                    .opacity(gameVM.isNextButtonEnabled ? 1.0 : 0.6) // Alteração aqui
                                    .containerShape(RoundedRectangle(cornerRadius: 10))
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 60)
                        }
                        
                        .padding()
                        .disabled(!gameVM.isNextButtonEnabled)
                        .sheet(isPresented: $isPresented, content: {
                            ModalView(fishVC: fishVC, isPresented: $isPresented, showPhasesView: $showPhasesView, currentIndex: gameVM.currentPhaseIndex, gameVM: gameVM)
                        })
                        .sheet(isPresented: $isPresentedFinal, content: {
                            FinalModalView(currentIndex: gameVM.currentPhaseIndex, gameVM: gameVM, isPresentedFinal: $isPresentedFinal, showPhasesView: $showPhasesView)
                        })
                    }
                }
                .frame(height: 30)
                .padding(.bottom, 30)
                .offset(x: -8)
                
            }
        }
        .background(Color(gameVM.phases[gameVM.currentPhaseIndex].name))
        .onChange(of: gameVM.currentPhaseIndex) { newIndex in
            isPresented.toggle()
        }
        

    }
    
    private func bindingForStep(_ step: Int, inPhase phase: Int) -> Binding<Double> {
        switch (phase, step) {
        case (0,0):
            return Binding(
                get: {
                    sliderSoil
                },
                set: { newValue in
                    sliderSoil = newValue
                    fishVC.updateSoil() 
                }
            )
        case (0,1):
            return Binding(
                get: {
                    sliderNutrition
                },
                set: { newValue in
                    sliderNutrition = newValue
                    fishVC.updateSoilNutritionColor()
                }
            )

        case (1,0):
            return Binding(
                get: {
                    sliderWater
                },
                set: { newValue in
                    sliderWater = newValue
                    fishVC.updateWater()
                }
            )
        case (1,1):
            return Binding(
                get: {
                    sliderWaterPurity
                },
                set: { newValue in
                    sliderWaterPurity = newValue
                    fishVC.updateWaterPurityColor()
                }
            )
        case (1, 2):
            return Binding(
                get: {
                    self.sliderTree
                },
                set: { newValue in
                    self.sliderTree = newValue
                    self.fishVC.updateTree()
                }
            )

        case (1, 3):
            return Binding(
                get: {
                    self.sliderRock
                },
                set: { newValue in
                    self.sliderRock = newValue
                    self.fishVC.updateRock()

                }
            )

        case (2,0):
            return Binding(
                get: {
                    sliderGrass
                },
                set: { newValue in
                    sliderGrass = newValue
                    fishVC.updateGrass()
                }
            )
        case (2,1):
            return Binding(
                get: {
                    sliderLight
                },
                set: { newValue in
                    sliderLight = newValue
                    fishVC.updateLuminosity()
                    fishVC.updateAlgae()
                    fishVC.updateGrassColor()
                }
            )
        case (2, 2):
            return Binding(
                get: {
                    self.sliderFish
                },
                set: { newValue in
                    self.sliderFish = newValue
                    self.fishVC.updateFish()
                    self.fishVC.updateAmmonia()
                }
            )
        default:
            return .constant(1)
        }
    }

    private func isSliderDisabled(for step: Int) -> Bool {
        let currentStep = gameVM.phases[gameVM.currentPhaseIndex].steps[step]
        let previousStep = step > 0 ? gameVM.phases[gameVM.currentPhaseIndex].steps[step - 1] : nil

        return step > 0 && (!currentStep.isEnabled ||
                            (previousStep?.isEnabled == true &&
                             !(previousStep!.minIdealrange...previousStep!.maxIdealrange).contains(bindingForStep(step - 1, inPhase: gameVM.currentPhaseIndex).wrappedValue))) ||
               (step == 0 && !currentStep.isEnabled) ||
               (step == 0 && (currentStep.minIdealrange...currentStep.maxIdealrange).contains(bindingForStep(step, inPhase: gameVM.currentPhaseIndex).wrappedValue))
    }

    private func handleSliderChange(_ step: Int, _ newValue: Double) {
        let minIdealRange = gameVM.phases[gameVM.currentPhaseIndex].steps[step].minIdealrange
        let maxIdealRange = gameVM.phases[gameVM.currentPhaseIndex].steps[step].maxIdealrange

        if (minIdealRange...maxIdealRange).contains(newValue) {
            gameVM.phases[gameVM.currentPhaseIndex].steps[step].isEnabled = false

            // Activate the next slider if there is one
            let nextStepIndex = step + 1
            if nextStepIndex < gameVM.phases[gameVM.currentPhaseIndex].steps.count {
                gameVM.phases[gameVM.currentPhaseIndex].steps[nextStepIndex].isEnabled = true
            }
        } else {
            // If the slider value is not within the ideal range, keep the current slider enabled
            gameVM.phases[gameVM.currentPhaseIndex].steps[step].isEnabled = true
        }
    }

}
