import ARKit
import SwiftUI

class ARSceneViewController: UIViewController, ARSCNViewDelegate {
    let scene: SCNScene
    var sceneARView: ARSCNView!

    init(scene: SCNScene) {
        self.scene = scene
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
    }
    
    private func setupView() {
        // Configurar a ARSCNView conforme necessário
        sceneARView = ARSCNView(frame: self.view.frame)
        sceneARView.autoenablesDefaultLighting = true
        sceneARView.delegate = self
        sceneARView.scene = scene
        view.addSubview(sceneARView)

        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = [.horizontal, .vertical]
        configuration.planeDetection = []
        sceneARView.session.run(configuration, options: [])
    }



    
    
}

// Update do UIViewRepresentable para a ARSceneViewController
struct ARSceneViewRepresentable: UIViewControllerRepresentable {
    let scene: SCNScene
    
    func makeUIViewController(context: Context) -> ARSceneViewController {
        return ARSceneViewController(scene: scene)
    }
    
    func updateUIViewController(_ uiViewController: ARSceneViewController, context: Context) {}
}
