import SwiftUI
import SceneKit

struct FishRepresentable: UIViewControllerRepresentable {
    var fishViewController: FishViewController
    var scene: SCNScene?

    @Binding var sliderFishValue: Double
    @Binding var sliderGrass: Double
    @Binding var sliderFish: Double
    @Binding var sliderPH: Double
    @Binding var sliderWaterPurity: Double
    @Binding var sliderWater: Double
    @Binding var sliderSoil: Double
    @Binding var sliderNutrition: Double
    @Binding var sliderTree: Double
    @Binding var sliderRock: Double

    func makeUIViewController(context: Context) -> FishViewController {
        fishViewController.scene = scene!
        return fishViewController
    }

    func updateUIViewController(_ uiViewController: FishViewController, context: Context) {
        uiViewController.sliderLight = sliderFishValue
        uiViewController.sliderGrass = sliderGrass
        uiViewController.sliderFish = sliderFish
        uiViewController.sliderPH = sliderPH
        uiViewController.sliderWaterPurity = sliderWaterPurity
        uiViewController.sliderWater = sliderWater
        uiViewController.sliderSoil = sliderSoil
        uiViewController.sliderNutrition = sliderNutrition
        uiViewController.sliderTree = sliderTree
        uiViewController.sliderRock = sliderRock
    }
}
