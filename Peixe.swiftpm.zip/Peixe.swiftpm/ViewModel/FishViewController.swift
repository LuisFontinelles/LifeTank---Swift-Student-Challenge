import ARKit
import SwiftUI
import QuartzCore

class FishViewController: UIViewController, ARSCNViewDelegate, ObservableObject {
    
    
    //sounds
    let waterFilling = SCNAction.playAudio(SCNAudioSource(fileNamed: "waterFillingOST.mp3")!, waitForCompletion: true)
    let treeOST = SCNAction.playAudio(SCNAudioSource(fileNamed: "treeOST.mp3")!, waitForCompletion: true)
    let soilOST = SCNAction.playAudio(SCNAudioSource(fileNamed: "soilOST.mp3")!, waitForCompletion: true)
    let rockOST = SCNAction.playAudio(SCNAudioSource(fileNamed: "rockOST.mp3")!, waitForCompletion: true)
    let grassOST = SCNAction.playAudio(SCNAudioSource(fileNamed: "grassOST.mp3")!, waitForCompletion: true)
    let fishOST = SCNAction.playAudio(SCNAudioSource(fileNamed: "fishOST.mp3")!, waitForCompletion: true)
    
    var defaultWaterMaterial: SCNMaterialProperty!
    let soilSOund = SCNAction.playAudio(SCNAudioSource(fileNamed: "soilSound.mp3")!, waitForCompletion: true)
    
    //scenes
    var scene3DView = SCNView()
    var sceneARView = ARSCNView()
    var scene: SCNScene
    
    //animation
    var displayLink: CADisplayLink?
    var currentFrame = 1  // water animation current frame
    
    //nodes
    var waterNode: SCNNode!
    var soilNode: SCNNode!
    var treeNode: SCNNode!
    var rockNode: SCNNode!
    
    //array nodes
    var grassNodes: [GrassNode] = []
    var plantNodes: [PlantNode] = []
    var fishNodes: [FishNode] = []
    
    //ambient
    var sliderLight: Double = 0
    var ambientLight: SCNLight!
    var directionalLight: SCNLight!
    
    // sliders
    var sliderWater: Double = 0
    var sliderWaterPurity: Double = 0
    var sliderSoil: Double = 0
    var sliderGrass: Double = 0
    var sliderNutrition: Double = 0
    var sliderPH: Double = 0
    var sliderFish: Double = 0
    var sliderTree: Double = 0
    var sliderRock: Double = 0
    
    init(scene: SCNScene) {
        self.scene = scene
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupScene()
        setupAmbient()
        setupWater()
        setupWaterTexture()
        setupDisplayLink()
        setupTree()
        setupRock()
        setupSoil()
    }
    
    //--------------------------------------------------------//
    //--------------------------------------------------------//
    
        
    /// MARK: - SCENES
    func setupScene() {
        scene3DView = SCNView(frame: view.frame)
        scene3DView.autoenablesDefaultLighting = true
//        scene3DView.showsStatistics = true
        scene3DView.antialiasingMode = .multisampling4X
        scene3DView.allowsCameraControl = true
        scene3DView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(scene3DView)
        scene3DView.scene = scene
    }
    func setupAR() {    //change view to AR
        sceneARView = ARSCNView(frame: scene3DView.frame)
        sceneARView.autoenablesDefaultLighting = true
        sceneARView.delegate = self
        sceneARView.showsStatistics = true
        sceneARView.scene = scene
        view.addSubview(sceneARView)
        let configuration = ARWorldTrackingConfiguration()
        configuration.planeDetection = .horizontal
        sceneARView.session.run(configuration, options: [.resetTracking, .removeExistingAnchors])
    }
    
    func setupAmbient() {
        ambientLight = SCNLight()
        ambientLight.type = .ambient
        ambientLight.intensity = CGFloat(sliderLight)/2
        
        directionalLight = SCNLight()
        directionalLight.type = .directional
        directionalLight.intensity = CGFloat(sliderLight)
        
        let ambientNode = SCNNode()
        ambientNode.light = ambientLight
        
        let directionalNode = SCNNode()
        directionalNode.light = directionalLight
        directionalNode.position = SCNVector3(x: 0, y: 10, z: 0)
        
        scene.rootNode.addChildNode(ambientNode)
        scene.rootNode.addChildNode(directionalNode)
    }
    
    
    func setupSoil() {
        guard let soil = scene.rootNode.childNode(withName: "soil", recursively: true) else {
            fatalError()
        }
        
        soilNode = soil
        soilNode.castsShadow = false
        soilNode.scale.y = 0
        soilNode.isHidden = true
        soilNode.pivot = SCNMatrix4MakeTranslation(0, -0.5, 0)
        //        scene.rootNode.addChildNode(waterNode)
        
    }
    
    func setupWater() {
        guard let water2 = scene.rootNode.childNode(withName: "water", recursively: true) else {
            fatalError()
        }
        waterNode = water2
        waterNode.scale.y = 0
        waterNode.isHidden = true
        waterNode.castsShadow = false
        waterNode.pivot = SCNMatrix4MakeTranslation(0, -2.5, 0)
        //        scene.rootNode.addChildNode(waterNode)
    }
    
    func setupTree() {
        guard let tree = scene.rootNode.childNode(withName: "tree", recursively: true) else {
            fatalError()
        }
        treeNode = tree
        
        guard let grassScene = SCNScene(named: "tree05.scn") else {
            fatalError("Erro ao carregar a cena de grama do arquivo .scn")
        }
        
        for childNode in grassScene.rootNode.childNodes {
            treeNode.geometry = childNode.geometry
        }
        tree.isHidden = true
        
    }
    
    func setupRock() {
        guard let rock = scene.rootNode.childNode(withName: "rock", recursively: true) else {
            fatalError()
        }
        rockNode = rock
        
    }
    
    //--------------------------------------------------------//
    //--------------------------------------------------------//
    
    ///MARK: - UPDATE VIEW METHODS
    
    func updateFish() {    //update instances of fishes on view
        let difference = Int(sliderFish) - fishNodes.count
        
        if difference > 0 {
            for _ in 0..<Int(difference) {
                let fishNode = FishNode()
                fishNodes.append(fishNode)
                if !fishNodes[0].hasActions {
                    fishNodes[0].runAction(fishOST)
                }
                scene.rootNode.addChildNode(fishNode)
            }
        } else if difference < 0 {
            // remove last instance from array
            let removedNodes = fishNodes.suffix(-Int(difference))
            for removedNode in removedNodes {
                removedNode.removeFromParentNode()
            }
            fishNodes.removeLast(-Int(difference))
        }
        
        
    }
    
    func updateWater() {    //change waternode scale
        if waterNode.scale.y == 0 {
            waterNode.isHidden = true
        } else {
            waterNode.isHidden = false
        }
        waterNode.scale.y = Float(sliderWater)
        let i: Double = 0.5 - sliderWaterPurity
        waterNode.geometry?.firstMaterial?.diffuse.contents = UIColor(red: i, green: i, blue: i, alpha: i)
        
        
        if !waterNode.hasActions {
            waterNode.runAction(waterFilling)
        }
        
    }
    
    func updateSoil() {
        if soilNode.scale.y == 0 {
            soilNode.isHidden = true
        } else {
            soilNode.isHidden = false
        }
        
        soilNode.scale.y = Float(sliderSoil)
        
        if !soilNode.hasActions {
            soilNode.runAction(soilOST)
        }
    }
    
    
    
    func updateLuminosity() {    // control intensity of scnlights
        ambientLight.intensity = CGFloat(sliderLight)/2
        directionalLight.intensity = CGFloat(sliderLight)
    }
    
    func updateAlgae() {    //update waternode color
        let indexAlpha = CGFloat(Double(sliderLight - 800) * 0.7 / 200.0)
        
        if sliderLight > 800 {
            waterNode.geometry?.firstMaterial?.diffuse.contents = UIColor(hue: 120/360, saturation: 1, brightness: 0.5, alpha: indexAlpha)
        }
        else {
            waterNode.geometry?.firstMaterial?.diffuse.contents = UIColor(red: 0, green: 0, blue: 0, alpha: 0.01)
        }
        
    }    
    func updateAmmonia() {    //update waternode color
        let indexAlpha = CGFloat(Double(sliderFish - 25) * 0.7 / 5)
        
        if sliderFish > 25 {
            waterNode.geometry?.firstMaterial?.diffuse.contents = UIColor(hue: 0.2083, saturation: 1, brightness: 0.5, alpha: indexAlpha)
        }
        else {
            waterNode.geometry?.firstMaterial?.diffuse.contents = UIColor(red: 0, green: 0, blue: 0, alpha: 0.01)
        }
        
    }
    
    func updateSoilNutritionColor() {    //update soilnode color
        let ir = CGFloat(Double(sliderNutrition) * 0.5)
        let ig = CGFloat(Double(sliderNutrition) * 0.25)
        let ib = CGFloat(Double(sliderNutrition) * 0.25)
        soilNode.geometry?.firstMaterial?.diffuse.contents = UIColor(red: ir, green: ig, blue: ib, alpha: 1)
    }
    
    func updateGrass() {    //create or remove grasses
        let difference = Int(sliderGrass) - grassNodes.count
        
        if difference > 0 {
            for _ in 0..<difference {
                let grassNode = GrassNode()
                if grassNode.name == "grass" && grassNodes.count > 200{
                    grassNode.scale.y = Float(CGFloat.random(in: 0.4 ... 0.5))
                }

                grassNodes.append(grassNode)
                if !grassNodes[0].hasActions {
                    grassNodes[0].runAction(grassOST)
                }

                scene.rootNode.addChildNode(grassNode)
            }
        } else {
            // Remove excess grass nodes
            grassNodes.suffix(-difference).forEach { $0.removeFromParentNode() }
            grassNodes.removeLast(-difference)
        }
    }
    
    func updateWaterPurityColor() {    //change waternode color
        let i: Double = 0.5 - sliderWaterPurity
        waterNode.geometry?.firstMaterial?.diffuse.contents = UIColor(red: i, green: i, blue: i, alpha: i)
        print(i)

    }
    
    func updateGrassColor() {
        let index = CGFloat(Double(sliderLight + 200) / 800)
        let index2 = CGFloat(Double(sliderLight - 800) * 0.8 / 200)
        for grassNode in grassNodes {
            for childNode in grassNode.childNodes {
                childNode.geometry?.materials.forEach { material in
                    material.diffuse.contents = UIColor(red: sliderLight < 800 ? 1-index :  index2 , green: 0.8, blue: 0.3, alpha: 1)
                }
            }
        }
    }

    
    //--------------------------------------------------------//
    //--------------------------------------------------------//
    
    
    ///MARK: - ANIMATION
    func setupWaterTexture() {    //create a move animation on normalmap
        let animation = CABasicAnimation(keyPath: "contentsTransform")
        animation.fromValue = NSValue(caTransform3D: CATransform3DIdentity)
        animation.toValue = NSValue(caTransform3D: CATransform3DMakeTranslation(0, -1, 0))
        animation.repeatCount = .greatestFiniteMagnitude
        animation.duration = 120.0
        waterNode.geometry?.firstMaterial?.normal.addAnimation(animation, forKey: "contentsTransformAnimation")
        
    }
    
    func setupDisplayLink() {
        displayLink = CADisplayLink(target: self, selector: #selector(updateDisplay))
        displayLink?.add(to: .main, forMode: .default)
    }
    
    @objc func updateDisplay(){
        updateNormalMap()
    }
    
    func updateNormalMap() {    //change normalmap frames for animation ilusion
        if let normalMap = UIImage(named: String(format: "%04d", currentFrame)) {
            waterNode.geometry?.firstMaterial?.normal.contents = normalMap
            currentFrame += 1
            if currentFrame == 120 {
                currentFrame = 1  //reset frame
            }
            waterNode.geometry?.firstMaterial?.normal.intensity = 0.2
            
        }
    }
    
    func updateTree() {
        if !treeNode.hasActions {
            treeNode.runAction(treeOST)
        }
        switch (sliderTree) {
        case 1:
            treeNode.isHidden = false
            guard let grassScene = SCNScene(named: "tree05.scn") else {
                fatalError("Erro ao carregar a cena de grama do arquivo .scn")
            }
            
            for childNode in grassScene.rootNode.childNodes {
                treeNode.geometry = childNode.geometry
            }
        case 2:
            treeNode.isHidden = false
            guard let grassScene = SCNScene(named: "tree04.scn") else {
                fatalError("Erro ao carregar a cena de grama do arquivo .scn")
            }
            
            for childNode in grassScene.rootNode.childNodes {
                treeNode.geometry = childNode.geometry
            }
        case 3:
            treeNode.isHidden = false
            guard let grassScene = SCNScene(named: "tree03.scn") else {
                fatalError("Erro ao carregar a cena de grama do arquivo .scn")
            }
            
            for childNode in grassScene.rootNode.childNodes {
                treeNode.geometry = childNode.geometry
            }
        case 4:
            treeNode.isHidden = false
            guard let grassScene = SCNScene(named: "tree02.scn") else {
                fatalError("Erro ao carregar a cena de grama do arquivo .scn")
            }
            
            for childNode in grassScene.rootNode.childNodes {
                treeNode.geometry = childNode.geometry
            }
            
        case 5:
            treeNode.isHidden = false
            
            guard let grassScene = SCNScene(named: "tree01.scn") else {
                fatalError("Erro ao carregar a cena de grama do arquivo .scn")
            }
            
            for childNode in grassScene.rootNode.childNodes {
                treeNode.geometry = childNode.geometry
            }
        default:
            treeNode.geometry = SCNGeometry()
            
        }
    }
    func updateRock() {
        if !rockNode.hasActions {
            rockNode.runAction(rockOST)
        }
        switch (sliderRock) {
            
        case 1:
            
            guard let grassScene = SCNScene(named: "rock01.scn") else {
                fatalError("Erro ao carregar a cena de grama do arquivo .scn")
            }
            
            for childNode in grassScene.rootNode.childNodes {
                rockNode.geometry = childNode.geometry
            }
        case 2:
            
            guard let grassScene = SCNScene(named: "rock02.scn") else {
                fatalError("Erro ao carregar a cena de grama do arquivo .scn")
            }
            
            for childNode in grassScene.rootNode.childNodes {
                rockNode.geometry = childNode.geometry
            }
        case 3:
            
            guard let grassScene = SCNScene(named: "rock03.scn") else {
                fatalError("Erro ao carregar a cena de grama do arquivo .scn")
            }
            
            for childNode in grassScene.rootNode.childNodes {
                rockNode.geometry = childNode.geometry
            }
        case 4:
            
            guard let grassScene = SCNScene(named: "rock04.scn") else {
                fatalError("Erro ao carregar a cena de grama do arquivo .scn")
            }
            
            for childNode in grassScene.rootNode.childNodes {
                rockNode.geometry = childNode.geometry
            }
        case 5:
            
            guard let grassScene = SCNScene(named: "rock05.scn") else {
                fatalError("Erro ao carregar a cena de grama do arquivo .scn")
            }
            
            for childNode in grassScene.rootNode.childNodes {
                rockNode.geometry = childNode.geometry
            }
        default:
            rockNode.geometry = SCNGeometry()
        }
    }
}


