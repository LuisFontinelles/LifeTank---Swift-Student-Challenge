import Foundation
import SwiftUI

class GameViewModel: ObservableObject {
    @Published var currentPhaseIndex: Int = 0
    
    var isNextButtonEnabled: Bool {
        return !phases[currentPhaseIndex].steps.contains(where: { $0.isEnabled })
    }

    
    @Published var phases: [PhaseModel] = [
            PhaseModel(name: "Foundation", description: "In the first stage, Foundation, we're about to build the core of your simulated aquarium. Here, we'll delve into soil and nutrients. The soil acts as vital support, housing bacteria and facilitating filtration. Nutrients are the key to plant growth. Together, they form the backbone of your ecosystem, providing the necessary foundation for life to thrive.",
                       steps: [
                        StepModel(name: "Soil", sliderValue: 0.0, maxSliderRange: 1, isEnabled: true, description: "Soil is where bacteria reside, filtering and supporting plants. It stores vital nutrients, crucial for plant growth. Essentially, it kickstarts life in your aquarium by providing a solid base for plant sustenance and overall ecosystem health.", maxIdealrange: 1, minIdealrange: 1),
                        StepModel(name: "Nutrients", sliderValue: 0.0, maxSliderRange: 1, isEnabled: false, description: "Nutrients are the fuel for aquatic life. They provide essential elements necessary for plant growth and overall ecosystem balance. Essentially, they act as the building blocks, ensuring vibrant plant life and a thriving aquatic environment.", maxIdealrange: 1, minIdealrange: 1),
                       ]),
            PhaseModel(name: "Aquatic Medium", description: "Moving on to the second stage, Aquatic Medium, we step into the aquatic realm. We'll address water, water purity, organic material, and water hardness. This stage is the virtual representation of aquatic dynamics. Water is the lifeblood, and its purity and organic composition directly influence the balance of the environment. Together, these steps constitute the pulsating heart of your simulated aquarium.",
                       steps: [
                        StepModel(name: "Water", sliderValue: 0.0, maxSliderRange: 1, isEnabled: true, description: "Water is life's foundation in your aquatic ecosystem. It's essential for transporting nutrients and oxygen, vital for every organism. Essentially, it's the lifeline that keeps your aquarium thriving.", maxIdealrange: 1, minIdealrange: 1),
                        StepModel(name: "Water Purity", sliderValue: 0.0, maxSliderRange: 0.49, isEnabled: false, description: "Maintaining water purity is essential for the health and longevity of your aquatic ecosystem. By implementing filtration and aeration systems, you can remove impurities and pollutants, ensuring a pristine and healthy environment for all inhabitants.", maxIdealrange: 0.49, minIdealrange: 0.42),
                        StepModel(name: "Organic Material", sliderValue: 0.0, maxSliderRange: 5, isSliderStep: true, isEnabled: false, description: "Organic material plays a vital role in the nutrient cycle and provides a natural food source for various organisms. By carefully introducing and managing organic matter, you can promote a balanced and thriving ecosystem.", maxIdealrange: 4, minIdealrange: 2),
                        StepModel(name: "Water hardness", sliderValue: 0.0, maxSliderRange: 5, isSliderStep: true, isEnabled: false, description: "Water hardness, influenced by the presence of minerals, affects the pH and overall chemistry of your aquatic ecosystem. Understanding and adjusting water hardness to suit specific plant and fish species is crucial for their long-term health and success.", maxIdealrange: 4, minIdealrange: 2),
                       ]),
            PhaseModel(name: "Biodiversity", description: "In the third stage, Biodiversity, attention shifts to biological diversity. We'll explore plants, luminance, and fishes. These elements are vital for creating a vibrant ecosystem. Plants provide oxygen and stability, luminance guides life, and fishes bring movement and interaction. In essence, this stage completes the simulation, offering a glimpse into the complexity and beauty of aquatic biodiversity.",
                       steps: [
                        StepModel(name: "Plant",sliderValue: 0.0, maxSliderRange: 300, isSliderStep: true, isEnabled: true, description: "Plants are the cornerstone of any aquatic ecosystem, providing oxygen, removing pollutants, and offering food and shelter for various organisms. Choose a diverse range of plant species to promote a healthy and balanced environment.", maxIdealrange: 240, minIdealrange: 180),
                        StepModel(name: "Luminance", sliderValue: 0.0, maxSliderRange: 1000, isEnabled: false, description: "Light is essential for photosynthesis and plays a crucial role in plant growth and overall ecosystem health. By providing the appropriate lighting intensity and duration, you can stimulate optimal plant growth and create a visually stunning underwater world.", maxIdealrange: 800, minIdealrange: 660),
                        StepModel(name: "Fish", sliderValue: 0.0, maxSliderRange: 30, isSliderStep: true, isEnabled: false, description: "Fishes are pivotal for the aquarium environment as they actively propel the food chain across all levels of the pyramid. Their role extends beyond mere movement; they produce organic matter like ammonia, serving as a nutrient source for nitrobacteria. Essentially, fishes are the key players in maintaining a robust and thriving ecosystem, ensuring a dynamic balance in your aquarium's biodiversity.", maxIdealrange: 30, minIdealrange: 16)

                       ]),

            
        ]
    
    func nextPhase() {
        if currentPhaseIndex < phases.count - 1 {
            currentPhaseIndex += 1
        } 
    }


    
}
